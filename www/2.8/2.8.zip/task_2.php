<?php

$a = 76;
$b = 8;

echo $a % $b;
