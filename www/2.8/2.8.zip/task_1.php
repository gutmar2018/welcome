<?php

$a = 5;
$b = 4.456;
$c = 10;

var_dump($a + $b <= $c);
